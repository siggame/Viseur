import * as Settings from "src/viseur/settings";
Settings.BaseSetting.newIndex = 0; // reset to zero for these new settings

export const GameSettings = {
    // <<-- Creer-Merge: settings -->>
    // put settings here, look at previous games for examples
    // <<-- /Creer-Merge: settings -->>
};
